import React, { useContext, useState } from 'react';
import { GrSearch } from "react-icons/gr";
import { FaUserCircle, FaShoppingCart } from "react-icons/fa";
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import SummaryApi from '../common';
import { toast } from 'react-toastify';
import { setUserDetails } from '../store/userSlice';
import ROLE from '../common/role';
import Context from '../context';

const Header = () => {
  const user = useSelector(state => state?.user?.user);
  const dispatch = useDispatch();
  const [menuDisplay, setMenuDisplay] = useState(false);
  const context = useContext(Context);
  const navigate = useNavigate();
  const searchInput = useLocation();
  const URLSearch = new URLSearchParams(searchInput?.search);
  const searchQuery = URLSearch.getAll("q");
  const [search, setSearch] = useState(searchQuery);

  const handleLogout = async () => {
    const fetchData = await fetch(SummaryApi.logout_user.url, {
      method: SummaryApi.logout_user.method,
      credentials: 'include'
    });

    const data = await fetchData.json();

    if (data.success) {
      toast.success(data.message);
      dispatch(setUserDetails(null));
      navigate("/");
    }

    if (data.error) {
      toast.error(data.message);
    }
  }

  const handleSearch = (e) => {
    const { value } = e.target;
    setSearch(value);

    if (value) {
      navigate(`/search?q=${value}`);
    } else {
      navigate("/search");
    }
  }

  return (
    <header className='h-16 shadow-md bg-white fixed w-full z-40'>
      <div className='h-full container mx-auto flex items-center px-4 justify-between'>
        <div className='flex items-center'>
          <img
            src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAeFBMVEX///8AAAD8/PyHh4fZ2dnPz8+RkZH5+fno6Ojy8vL29vbu7u7i4uJGRkZ4eHjExMSpqanV1dVYWFi1tbUeHh5ERESMjIyBgYE6OjoTExNUVFRNTU1ycnKXl5e8vLxgYGCurq4xMTEODg4oKChoaGifn58uLi4ZGRnJbgt5AAAIOklEQVR4nO2dC5eqLBfHATW8XyrTSrOLNt//G74bTIXJc5p5n5kTtfZvzZpCqcVfNrA3iBGCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCmAf7w/s3wp3w+Ttq7OjE+S1rMVsONFcaPrs0v0xHk2cX4VeYDDOhiyeW418Q0PbZRfhl/O362UX4bfb0HftSlZhmzy7CL3Okq2cX4ZdxaPGWY/4Ep7sf/kZm2hVbfxSF9U02fzlXGNeuG/rDbMyqQ0Y2tLPvSegunFLhdquk7IKulNSKxkqqAjfQKIXCb+tmjgZ0rya3H2pqQ20ltaKpkipp8IOF+xHsWb/Npyc1+bFVU7EWkNSq885pZFoVMqJrGRCamJaaPtFqCgs1lZjWDAUn6s0cvVC1pOuzem6vWWKupiwTo7FYa1UDJeVKSlXI4JynpOhVyRhR/6fL99/pZv02qCc2VSLUqML6Q1GvtDwGzVfroAzBgaZzT6O1tasWgVA14rJpNb5nyex3PRt31m8rwHYnVZ8UqnYpRptblTIzmyFhugneqKmjKDwprRJaXqlkTMHIRyvVW68x7Oc6005TWKodiActb6KAAHPIGIB248YKIlwU5/5gSg9/UujSpZKxgeszZBTzWiYq1N2u2YO5qjDUvKCT0kStuWtlADaN7698QmsllauGbEPQPMJVk72a55RK/Dlf0tb6fW0gz1TxnlKhPs2NNNLef2GEdwuFgkb1ZkjUV2pNpyq6XIynYsg3nTBzell40i78d38g+jVxNBR0fb+ZORPZgUZKKqeHKbGhmzFrVtF0SGSXWR/eBPRepYdrw/pS7ULEBRkR9X/DTKdUog9wPXythvXLSQchi9EYmeiDxuOHmQtlBiIIvu8CS9WX0xRa4zQ5Y74SVxWGjoZCYTQzjkVqCNxMCpkyicHAT5vc9pwaumLOREhwHwQv1XCiVeuwUhLK6B/8+NzyD3K889uYLkqbmWnHLpOBczfO1B0MdUolGbXujmmTG5rCnTIoKKvk5jZD0kc9OkyPOCpVoRpoFNN1uJo4RTOy/hwEM/0eBm2G9LKeepSpj3KNdUolzf1NJ9rComay09jCyPYMPZVMmjsaSup7j/JAj1NCVzjFS/7NvD3nGJncDIXfdtBNjOnrGYWmcDnmDWljp8W+d7tNboaMfC4dI47av44DJhP11sh3QXbcRL2209I6Zr7BrZCwmcKFyjyo5hJ4UG8ra3eR2rYRaAvkx00WOIvXV1Vf8GE9jWcra3mLBXdWmg1OATNwcfshrA84+mJDOBGuFrfl4o9lfHRMjQS/wy3aY164qste2zoCbTebZGzOts1HKTQMe+Fh0dzElUXnuHwu34txqxduJ4vzrb3t4855p5tQ/fBQt2sp7byv0mRwyl6vI5kB6o9bfc2dqi5xlTHyDdQJGAtOlMZ1Ehq5gPQDcIj8YvlOdJNvUm062TAd+Kb6RITx7ndiWtrK9jvS9QvW/6/IF7g4Ni35oz6mPznjsL2GD9fS5Xc9asbgonDf9z3yCmMMh2g9Xy73+12e52VZnk6ny+Xy8bHdfmFlrXj8/SaQlmqhz+fzdrtdr9eg83K9guBSAPLzSLCX7HZyC5Wpa4caoikFEk/iSzjwlVjpJRrif+HtBSLmwD69/jXvH0dHswkyx/6iQvASnMx7sSZoyxm1S/qlUncyYG7dxznNYQUBvlW3lDaPl6z9Hairiwulzks4NBKb9hGUu6fVA+NjpKE76eSl9IX2S0f9lhdGePlwY2IiA2bhqR9v8+MvQDjcWcOh/NXf80IVjtfgRF+lKY53lULN0PxBZnoZ7Xhm/dFQjsrtTtvLg95DrI7eJKYvM/8hbh6R4zfEfA/vUqNrTvq88zdSG0kw1IvoPe7vQNEZNuKBwq2xdyXe0dC6t7xg+7DzcEQlSqyHvZIxsIDSWCxVJGdhr3/PC8I+hHG6FV2bvIavwYm9pjQXS9gb8sCpYaLu6GVXUnp1X8Y1hSbl12LlqYWh7pFCOO+IJe9LBw7Cy1SixPvOngL3tbR9n1exzs98vdwvupqPIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCPJ13uR9dPPyBM8K43BByU8V97sNhzsVpn3H5JzLAAfGOiewi6ctX4kFuX6Z8j8utbp4nn+0tnqHJRb5nbsHglFbEP+eErIataewUx7HPz3FbgficpNW6bX1ii31P6b7Y2cQW+7b4Ja5icWX2cZPYVRRVjr+N24IQd1m1+4CQiJCkIatTXKXPMwlG6Dkm3hoKcxh+PozJx3DzJSHZThaTyL1dsdhCmiYkbEkY3zIIDv2DWw9HQoKGkCIjUQgqT4TsSQZ5Vkfy3GcQCIX+TWEP23uux6SAKuwVulD6anUAhal7THuFMhu8BmUmH+SdgnG2kDfM5KUqHLILxK7TVRcE3DCFpWUlhAmFG3tUuIASg8K2q24Kebkp5BZat9jDealw20YdSWSlpgeyb0EmOeyswnueQqYp/GylpPQGhWwbi9/RBSslJevrcPr9BDDcoQ4tB5qhOJYHJPL8nD/bShkTPY13LkGhdVPIoyAMOc8Du1mBHjhSuaQ7MhY2YKUBdB5h44Yez90whE+ETnAseoXQDr2ckTp23Xghm/AhJquFG7pPtFLWdQfCuyMh9vhrml29WASsXtSh6D3hwMojqdh8ePTtRd35JFjUYLQiGzTEYBF3MIRk0Bp9+JoEVCcF2C9j4qMdh4/UM7+u9M8Ejv+IPsjfHbt7bpv+MGxRSYwNu6IRBEEQ5J/zPxiJYEnQ3XR+AAAAAElFTkSuQmCC'           alt='Logo'
            style={{ width: '50px', height: '50px', marginRight: '10px' }}
          />
          <h6 style={{ fontSize: '1rem', fontWeight: 'bold', color: '#333', margin: 0, padding: 0 }}>Ecommerce</h6>
        </div>

        <div className='hidden lg:flex items-center w-full justify-between max-w-sm border rounded-full focus-within:shadow pl-2'>
          <input 
            type='text' 
            placeholder='search product here...' 
            className='w-full outline-none' 
            onChange={handleSearch} 
            value={search}
          />
          <div className='text-lg min-w-[50px] h-8 bg-red-600 flex items-center justify-center rounded-r-full text-white'>
            <GrSearch />
          </div>
        </div>

        <div className='flex items-center gap-7'>
          <div className='relative flex justify-center'>
            {user?._id && (
              <div 
                className='text-3xl cursor-pointer relative flex justify-center' 
                onClick={() => setMenuDisplay(prev => !prev)}
              >
                {user?.profilePic ? (
                  <img src={user?.profilePic} className='w-10 h-10 rounded-full' alt={user?.name} />
                ) : (
                  <FaUserCircle />
                )}
              </div>
            )}

            {menuDisplay && (
              <div className='absolute bg-white bottom-0 top-11 h-fit p-2 shadow-lg rounded'>
                <nav>
                  {user?.role === ROLE.ADMIN && (
                    <Link 
                      to={"/admin-panel/all-products"} 
                      className='whitespace-nowrap hidden md:block hover:bg-slate-100 p-2' 
                      onClick={() => setMenuDisplay(prev => !prev)}
                    >
                      Admin Panel
                    </Link>
                  )}
                </nav>
              </div>
            )}
          </div>

          {user?._id && (
            <Link to={"/cart"} className='text-2xl relative'>
              <span><FaShoppingCart /></span>
              <div className='bg-red-600 text-white w-5 h-5 rounded-full p-1 flex items-center justify-center absolute -top-2 -right-3'>
                <p className='text-sm'>{context?.cartProductCount}</p>
              </div>
            </Link>
          )}

          <div>
            {user?._id ? (
              <button 
                onClick={handleLogout} 
                className='px-3 py-1 rounded-full text-white bg-red-600 hover:bg-red-700'
              >
                Logout
              </button>
            ) : (
              <Link 
                to={"/login"} 
                className='px-3 py-1 rounded-full text-white bg-red-600 hover:bg-red-700'
              >
                Login
              </Link>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}

export default Header;
